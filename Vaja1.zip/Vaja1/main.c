//Maloc gre na heap
//Scak so pa zacasne spremenjivke
//Globalne spremenjivke grejo v zacetek rama	
#include <stdlib.h>

//extern void replaceSpaces(char * polje);
//extern void changeLetterCase(char * polje);
//extern char * deleteSpaces(char * polje);
extern int povecajZa(int a, int b);

	
int main(void){
			//char str[100] = "  Dober dan, kako smo kaj ?";
	
	//replaceSpaces(str);
	//changeLetterCase(str);
	//changeLetterCase(str);
	int i = povecajZa(10, 30);
	while(1);
}
